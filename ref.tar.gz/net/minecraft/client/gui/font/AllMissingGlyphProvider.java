package net.minecraft.client.gui.font;

import com.mojang.blaze3d.font.GlyphInfo;
import com.mojang.blaze3d.font.GlyphProvider;
import com.mojang.blaze3d.font.UnbakedGlyph;
import it.unimi.dsi.fastutil.ints.IntSet;
import it.unimi.dsi.fastutil.ints.IntSets;
import net.minecraft.client.gui.font.glyphs.BakedGlyph;
import net.minecraft.client.gui.font.glyphs.SpecialGlyphs;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jspecify.annotations.Nullable;

@OnlyIn(Dist.CLIENT)
public class AllMissingGlyphProvider implements GlyphProvider {
   private static final UnbakedGlyph MISSING_INSTANCE = new UnbakedGlyph() {
      @Override
      public GlyphInfo info() {
         return SpecialGlyphs.MISSING;
      }

      @Override
      public BakedGlyph bake(UnbakedGlyph.Stitcher stitcher) {
         return stitcher.getMissing();
      }
   };

   public AllMissingGlyphProvider() {
   }

   @Nullable
   @Override
   public UnbakedGlyph getGlyph(int codepoint) {
      return MISSING_INSTANCE;
   }

   @Override
   public IntSet getSupportedGlyphs() {
      return IntSets.EMPTY_SET;
   }
}
