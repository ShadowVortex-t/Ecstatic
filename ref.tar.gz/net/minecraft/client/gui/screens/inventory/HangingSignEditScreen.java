package net.minecraft.client.gui.screens.inventory;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.entity.SignTextSlot;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.joml.Vector3f;
import org.joml.Vector3fc;

@OnlyIn(Dist.CLIENT)
public class HangingSignEditScreen extends AbstractSignEditScreen {
   public static final float MAGIC_BACKGROUND_SCALE = 4.5F;
   private static final Vector3fc TEXT_SCALE = new Vector3f(1.0F, 1.0F, 1.0F);
   private static final int TEXTURE_WIDTH = 16;
   private static final int TEXTURE_HEIGHT = 16;
   private final Identifier texture = Identifier.parse(this.woodType.name() + ".png").withPrefix("textures/gui/hanging_signs/");

   public HangingSignEditScreen(SignBlockEntity sign, SignTextSlot slot, boolean shouldFilter) {
      super(sign, slot, shouldFilter, Component.translatable("hanging_sign.edit"));
   }

   @Override
   protected float getSignYOffset() {
      return 125.0F;
   }

   @Override
   protected void extractSignBackground(GuiGraphicsExtractor graphics) {
      graphics.pose().translate(0.0F, -13.0F);
      graphics.pose().scale(4.5F, 4.5F);
      graphics.blit(RenderPipelines.GUI_TEXTURED, this.texture, -8, -8, 0.0F, 0.0F, 16, 16, 16, 16);
   }

   @Override
   protected Vector3fc getSignTextScale() {
      return TEXT_SCALE;
   }
}
