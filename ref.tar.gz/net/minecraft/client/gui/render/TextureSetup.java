package net.minecraft.client.gui.render;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.textures.FilterMode;
import com.mojang.renderpearl.api.textures.GpuSampler;
import com.mojang.renderpearl.api.textures.GpuTextureView;
import net.minecraft.SharedConstants;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jspecify.annotations.Nullable;

@OnlyIn(Dist.CLIENT)
public record TextureSetup(
   @Nullable GpuTextureView texure0,
   @Nullable GpuTextureView texure1,
   @Nullable GpuTextureView texure2,
   @Nullable GpuSampler sampler0,
   @Nullable GpuSampler sampler1,
   @Nullable GpuSampler sampler2
) {
   private static final TextureSetup NO_TEXTURE_SETUP = new TextureSetup(null, null, null, null, null, null);
   private static int sortKeySeed;

   public static TextureSetup singleTexture(GpuTextureView texture, GpuSampler sampler) {
      return new TextureSetup(texture, null, null, sampler, null, null);
   }

   public static TextureSetup singleTextureWithLightmap(GpuTextureView texture, GpuSampler sampler) {
      return new TextureSetup(
         texture, null, Minecraft.getInstance().gameRenderer.lightmap(), sampler, null, RenderSystem.getSamplerCache().getClampToEdge(FilterMode.LINEAR)
      );
   }

   public static TextureSetup doubleTexture(GpuTextureView texture0, GpuSampler sampler0, GpuTextureView texture1, GpuSampler sampler1) {
      return new TextureSetup(texture0, texture1, null, sampler0, sampler1, null);
   }

   public static TextureSetup noTexture() {
      return NO_TEXTURE_SETUP;
   }

   public int getSortKey() {
      return SharedConstants.DEBUG_SHUFFLE_UI_RENDERING_ORDER ? this.hashCode() * (sortKeySeed + 1) : this.hashCode();
   }

   public static void updateSortKeySeed() {
      sortKeySeed = Math.round(100000.0F * (float)Math.random());
   }
}
