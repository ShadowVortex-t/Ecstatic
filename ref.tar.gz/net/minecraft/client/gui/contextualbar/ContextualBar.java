package net.minecraft.client.gui.contextualbar;

import com.mojang.blaze3d.platform.Window;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public interface ContextualBar {
   int WIDTH = 182;
   int HEIGHT = 5;
   int MARGIN_BOTTOM = 24;
   ContextualBar EMPTY = new ContextualBar() {
      @Override
      public void extractBackground(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
      }

      @Override
      public void extractRenderState(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
      }
   };

   default int left(Window window) {
      return (window.getGuiScaledWidth() - 182) / 2;
   }

   default int top(Window window) {
      return window.getGuiScaledHeight() - 24 - 5;
   }

   void extractBackground(GuiGraphicsExtractor var1, DeltaTracker var2);

   void extractRenderState(GuiGraphicsExtractor var1, DeltaTracker var2);

   static void extractExperienceLevel(GuiGraphicsExtractor graphics, Font font, int experienceLevel) {
      Component str = Component.translatable("gui.experience.level", experienceLevel);
      int x = (graphics.guiWidth() - font.width(str)) / 2;
      int y = graphics.guiHeight() - 24 - 9 - 2;
      graphics.text(font, str, x + 1, y, -16777216, false);
      graphics.text(font, str, x - 1, y, -16777216, false);
      graphics.text(font, str, x, y + 1, -16777216, false);
      graphics.text(font, str, x, y - 1, -16777216, false);
      graphics.text(font, str, x, y, -8323296, false);
   }
}
