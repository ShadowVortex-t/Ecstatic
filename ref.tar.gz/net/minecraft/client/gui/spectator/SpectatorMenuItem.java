package net.minecraft.client.gui.spectator;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public interface SpectatorMenuItem {
   void selectItem(SpectatorMenu var1);

   Component getName();

   void extractIcon(GuiGraphicsExtractor var1, float var2, float var3);

   boolean isEnabled();
}
