package net.minecraft.client.gui.screens.advancements;

import net.minecraft.advancements.AdvancementType;
import net.minecraft.resources.Identifier;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public enum AdvancementWidgetType {
   OBTAINED(
      Identifier.withDefaultNamespace("advancements/box_obtained"),
      Identifier.withDefaultNamespace("advancements/task_frame_obtained"),
      Identifier.withDefaultNamespace("advancements/challenge_frame_obtained"),
      Identifier.withDefaultNamespace("advancements/goal_frame_obtained")
   ),
   UNOBTAINED(
      Identifier.withDefaultNamespace("advancements/box_unobtained"),
      Identifier.withDefaultNamespace("advancements/task_frame_unobtained"),
      Identifier.withDefaultNamespace("advancements/challenge_frame_unobtained"),
      Identifier.withDefaultNamespace("advancements/goal_frame_unobtained")
   );

   private final Identifier boxSprite;
   private final Identifier taskFrameSprite;
   private final Identifier challengeFrameSprite;
   private final Identifier goalFrameSprite;

   private AdvancementWidgetType(Identifier boxSprite, Identifier taskFrameSprite, Identifier challengeFrameSprite, Identifier goalFrameSprite) {
      this.boxSprite = boxSprite;
      this.taskFrameSprite = taskFrameSprite;
      this.challengeFrameSprite = challengeFrameSprite;
      this.goalFrameSprite = goalFrameSprite;
   }

   public Identifier boxSprite() {
      return this.boxSprite;
   }

   public Identifier frameSprite(AdvancementType type) {
      return switch (type) {
         case TASK -> this.taskFrameSprite;
         case CHALLENGE -> this.challengeFrameSprite;
         case GOAL -> this.goalFrameSprite;
      };
   }
}
