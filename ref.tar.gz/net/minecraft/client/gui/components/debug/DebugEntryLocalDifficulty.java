package net.minecraft.client.gui.components.debug;

import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.LevelChunk;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jspecify.annotations.Nullable;

@OnlyIn(Dist.CLIENT)
public class DebugEntryLocalDifficulty implements DebugScreenEntry {
   public DebugEntryLocalDifficulty() {
   }

   @Override
   public void display(DebugScreenDisplayer displayer, @Nullable Level serverOrClientLevel, @Nullable LevelChunk clientChunk, @Nullable LevelChunk serverChunk) {
      Minecraft minecraft = Minecraft.getInstance();
      Entity entity = minecraft.getCameraEntity();
      if (entity != null && serverChunk != null && serverOrClientLevel instanceof ServerLevel serverLevel) {
         BlockPos feetPos = entity.blockPosition();
         if (serverLevel.isInsideBuildHeight(feetPos.getY())) {
            float moonBrightness = serverLevel.getMoonBrightness(feetPos);
            long localTime = serverChunk.getInhabitedTime();
            DifficultyInstance localDifficulty = new DifficultyInstance(
               serverLevel.getDifficulty(), serverLevel.getOverworldClockTime(), localTime, moonBrightness
            );
            displayer.addLine(
               String.format(Locale.ROOT, "Local Difficulty: %.2f // %.2f", localDifficulty.getEffectiveDifficulty(), localDifficulty.getSpecialMultiplier())
            );
         }
      }
   }
}
