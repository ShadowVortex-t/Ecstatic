package net.minecraft.client.gui.components;

import java.time.Duration;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.screens.inventory.tooltip.BelowOrAboveWidgetTooltipPositioner;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipPositioner;
import net.minecraft.client.gui.screens.inventory.tooltip.MenuTooltipPositioner;
import net.minecraft.util.Util;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jspecify.annotations.Nullable;

@OnlyIn(Dist.CLIENT)
public class WidgetTooltipHolder {
   @Nullable
   private Tooltip tooltip;
   private Duration delay = Duration.ZERO;
   private long displayStartTime;
   private boolean wasDisplayed;

   public WidgetTooltipHolder() {
   }

   public void setDelay(Duration delay) {
      this.delay = delay;
   }

   public void set(@Nullable Tooltip tooltip) {
      this.tooltip = tooltip;
   }

   @Nullable
   public Tooltip get() {
      return this.tooltip;
   }

   public void refreshTooltipForNextRenderPass(
      GuiGraphicsExtractor graphics, int mouseX, int mouseY, boolean isHovered, boolean isFocused, ScreenRectangle screenRectangle
   ) {
      if (this.tooltip == null) {
         this.wasDisplayed = false;
      } else {
         Minecraft minecraft = Minecraft.getInstance();
         boolean shouldDisplay = isHovered || isFocused && minecraft.getLastInputType().isKeyboard();
         if (shouldDisplay != this.wasDisplayed) {
            if (shouldDisplay) {
               this.displayStartTime = Util.getMillis();
            }

            this.wasDisplayed = shouldDisplay;
         }

         if (shouldDisplay && Util.getMillis() - this.displayStartTime > this.delay.toMillis()) {
            graphics.setTooltipForNextFrame(
               minecraft.font,
               this.tooltip.toCharSequence(minecraft),
               this.tooltip.component(),
               this.createTooltipPositioner(screenRectangle, isHovered, isFocused),
               mouseX,
               mouseY,
               isFocused,
               this.tooltip.style()
            );
         }
      }
   }

   private ClientTooltipPositioner createTooltipPositioner(ScreenRectangle screenRectangle, boolean isHovered, boolean isFocused) {
      return (ClientTooltipPositioner)(!isHovered && isFocused && Minecraft.getInstance().getLastInputType().isKeyboard()
         ? new BelowOrAboveWidgetTooltipPositioner(screenRectangle)
         : new MenuTooltipPositioner(screenRectangle));
   }

   public void updateNarration(NarrationElementOutput output) {
      if (this.tooltip != null) {
         this.tooltip.updateNarration(output);
      }
   }
}
