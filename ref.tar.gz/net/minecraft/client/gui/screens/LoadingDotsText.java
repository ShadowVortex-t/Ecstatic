package net.minecraft.client.gui.screens;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class LoadingDotsText {
   private static final String[] FRAMES = new String[]{"O o o", "o O o", "o o O", "o O o"};
   private static final long INTERVAL_MS = 300L;

   public LoadingDotsText() {
   }

   public static String get(long timeMs) {
      int index = (int)(timeMs / 300L % FRAMES.length);
      return FRAMES[index];
   }
}
