package net.minecraft.client.gui.components.debug;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.LevelChunk;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jspecify.annotations.Nullable;

@OnlyIn(Dist.CLIENT)
public class DebugEntryLookingAtEntity implements DebugScreenEntry {
   public static final Identifier GROUP = Identifier.withDefaultNamespace("looking_at_entity");

   public DebugEntryLookingAtEntity() {
   }

   @Override
   public void display(DebugScreenDisplayer displayer, @Nullable Level serverOrClientLevel, @Nullable LevelChunk clientChunk, @Nullable LevelChunk serverChunk) {
      Minecraft minecraft = Minecraft.getInstance();
      Entity entity = minecraft.crosshairPickEntity;
      List<String> result = new ArrayList<>();
      if (entity != null) {
         result.add(ChatFormatting.UNDERLINE + "Targeted Entity");
         result.add(entity.typeHolder().getRegisteredName());
         entity.getType().getTags().map(tag -> "#" + tag.location()).forEach(result::add);
      }

      displayer.addToGroup(GROUP, result);
   }
}
