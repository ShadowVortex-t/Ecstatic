package net.minecraft.client.gui.screens;

import it.unimi.dsi.fastutil.booleans.BooleanConsumer;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.MultiLineTextWidget;
import net.minecraft.client.gui.components.StringWidget;
import net.minecraft.client.gui.layouts.FrameLayout;
import net.minecraft.client.gui.layouts.LayoutElement;
import net.minecraft.client.gui.layouts.LinearLayout;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jspecify.annotations.Nullable;

@OnlyIn(Dist.CLIENT)
public class ConfirmScreen extends Screen {
   protected final Component message;
   protected final LinearLayout layout = LinearLayout.vertical().spacing(8);
   protected Component yesButtonComponent;
   protected Component noButtonComponent;
   @Nullable
   protected Button yesButton;
   @Nullable
   protected Button noButton;
   private int delayTicker;
   protected final BooleanConsumer callback;

   public ConfirmScreen(BooleanConsumer callback, Component title, Component message) {
      this(callback, title, message, CommonComponents.GUI_YES, CommonComponents.GUI_NO);
   }

   public ConfirmScreen(BooleanConsumer callback, Component title, Component message, Component yesButtonComponent, Component noButtonComponent) {
      super(title);
      this.callback = callback;
      this.message = message;
      this.yesButtonComponent = yesButtonComponent;
      this.noButtonComponent = noButtonComponent;
   }

   @Override
   public Component getNarrationMessage() {
      return CommonComponents.joinForNarration(super.getNarrationMessage(), this.message);
   }

   @Override
   protected void init() {
      super.init();
      this.layout.defaultCellSetting().alignHorizontallyCenter();
      this.layout.addChild(new StringWidget(this.title, this.font));
      this.layout.addChild(this.addMessage());
      this.addAdditionalText();
      LinearLayout buttonLayout = this.layout.addChild(LinearLayout.horizontal().spacing(4));
      buttonLayout.defaultCellSetting().paddingTop(16);
      this.addButtons(buttonLayout);
      this.layout.visitWidgets(this::addRenderableWidget);
      this.repositionElements();
   }

   @Override
   protected void repositionElements() {
      this.layout.arrangeElements();
      FrameLayout.centerInRectangle(this.layout, this.getRectangle());
   }

   protected void addAdditionalText() {
   }

   protected LayoutElement addMessage() {
      return new MultiLineTextWidget(this.message, this.font).setMaxWidth(this.width - 50).setMaxRows(15).setCentered(true);
   }

   protected void addButtons(LinearLayout buttonLayout) {
      this.yesButton = buttonLayout.addChild(Button.builder(this.yesButtonComponent, button -> this.callback.accept(true)).build());
      this.noButton = buttonLayout.addChild(Button.builder(this.noButtonComponent, button -> this.callback.accept(false)).build());
   }

   public void setDelay(int delay) {
      this.delayTicker = delay;
      this.yesButton.active = false;
      this.noButton.active = false;
   }

   @Override
   public void tick() {
      super.tick();
      if (--this.delayTicker == 0) {
         this.yesButton.active = true;
         this.noButton.active = true;
      }
   }

   @Override
   public boolean shouldCloseOnEsc() {
      return false;
   }

   @Override
   public boolean keyPressed(KeyEvent event) {
      if (this.delayTicker <= 0 && event.isEscape()) {
         this.callback.accept(false);
         return true;
      } else {
         return super.keyPressed(event);
      }
   }
}
